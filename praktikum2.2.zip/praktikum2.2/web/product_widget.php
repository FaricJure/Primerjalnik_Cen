<?php
/**
 * Created by IntelliJ IDEA.
 * User: Bojana
 * Date: 02.6.2019
 * Time: 14:09
 */
?>

<div class="product-widget">
    <div class="product-img">
        <img src="img/product07.png" alt="">
    </div>
    <div class="product-body">
<!--        <p class="product-category">--><?php //echo $product['subcategory'] ?><!--</p>-->
        <h3 class="product-name"><a href="#"><?php echo $product['name'] ?></a></h3>
        <h4 class="product-price"><?php echo $product['price'] ?></h4>
    </div>
</div>
